<?php
/* This file was supplied by Jonathan W Miner as a sample custom footer. */
?>
<TABLE align="center">
<TR>
  <TD>
    <a target="_blank" href="http://isc.sans.org"><img src="http://isc.sans.org/images/status.gif" border="0" alt="Internet Storm Center Infocon Status"></a>
  </TD>
  <TD>
    <a target="_blank" href="https://gtoc.iss.net/issEn/delivery/gtoc/index.jsp"><img src="http://www.iss.net/alertcon.php" width="83" height="70" border="0" alt="Internet Security Systems - AlertCon(TM)"></a>
  </TD>
  <TD>
    <A HREF="http://www.InternetTrafficReport.com/" target="_blank"> <IMG ALT="The Internet Traffic Report monitors the flow of data around the world. It then displays a value between zero and 100. Higher values indicate faster and more reliable connections." SRC="http://www.InternetTrafficReport.com/itr-clean.gif" WIDTH="125" HEIGHT="89" BORDER="0"> </A>
  </TD>
  <TD>
    <a target="_blank" href="https://tms.symantec.com/threatCon_Def.asp"><img border="0" src="http://www.securityfocus.com/sfonline/images/threatcon/ThreatConGraphic_header.gif" width="150" height="41"></a><br>
    <a target="_blank" href="https://tms.symantec.com/threatCon_Def.asp"><img border="0" src="http://www.securityfocus.com/sfonline/images/threatcon/threatcon.gif" width="150" height="27"></a><br>
    <a target="_blank" href="https://tms.symantec.com/threatCon_Def.asp"><img border="0" src="http://www.securityfocus.com/sfonline/images/threatcon/ThreatConGraphic_footer.gif" width="150" height="13"></a>
  </TD>
</TR>
</TABLE>
